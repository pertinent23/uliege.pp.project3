var annotated_dup =
[
    [ "GtkActionData_t", "structGtkActionData__t.html", "structGtkActionData__t" ]
];
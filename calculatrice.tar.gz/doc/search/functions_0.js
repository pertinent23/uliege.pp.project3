var searchData=
[
  ['add_5fbutton_37',['add_button',['../widgets_8c.html#abc504f2a558c0ba6d62e7a39476d7657',1,'add_button(GtkWidget *board, GtkWidget **button, GtkWidget **error):&#160;widgets.c'],['../widgets_8h.html#abc504f2a558c0ba6d62e7a39476d7657',1,'add_button(GtkWidget *board, GtkWidget **button, GtkWidget **error):&#160;widgets.c']]],
  ['add_5ffield_38',['add_field',['../widgets_8c.html#a2335f03908f020d7d0c0f725d659eefb',1,'add_field(GtkWidget *board, GtkWidget **field1, GtkWidget **field2):&#160;widgets.c'],['../widgets_8h.html#a2335f03908f020d7d0c0f725d659eefb',1,'add_field(GtkWidget *board, GtkWidget **field1, GtkWidget **field2):&#160;widgets.c']]],
  ['add_5flabel_39',['add_label',['../widgets_8c.html#abe0f4cfa7a7afeadc5c79ab4d017fd4b',1,'add_label(GtkWidget *board):&#160;widgets.c'],['../widgets_8h.html#abe0f4cfa7a7afeadc5c79ab4d017fd4b',1,'add_label(GtkWidget *board):&#160;widgets.c']]]
];

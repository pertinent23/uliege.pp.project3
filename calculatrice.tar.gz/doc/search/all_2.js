var searchData=
[
  ['calc_5fheight_4',['CALC_HEIGHT',['../tools_8h.html#a4dc5112e48cbcb16bac12ff015c614ce',1,'tools.h']]],
  ['calc_5fwidth_5',['CALC_WIDTH',['../tools_8h.html#ab2b34edbd92cf0fd45937ed66979573d',1,'tools.h']]],
  ['create_5fboard_6',['create_board',['../widgets_8c.html#a61578a3ab9da9c18fe9a643b5066f669',1,'create_board(void):&#160;widgets.c'],['../widgets_8h.html#a61578a3ab9da9c18fe9a643b5066f669',1,'create_board(void):&#160;widgets.c']]],
  ['create_5fbutton_7',['create_button',['../widgets_8c.html#a3664f09871e36b3872aa7641e880a355',1,'create_button(const char *button_icon):&#160;widgets.c'],['../widgets_8h.html#a3664f09871e36b3872aa7641e880a355',1,'create_button(const char *button_icon):&#160;widgets.c']]],
  ['create_5fdata_8',['create_data',['../tools_8c.html#abdb589bd6e2c178344a0f75a4e64e103',1,'create_data(GtkWidget *field1, GtkWidget *field2, GtkWidget *error, GtkWidget *window):&#160;tools.c'],['../tools_8h.html#acb2278452f2d44242063041e4575e8fa',1,'create_data(GtkWidget *field1, GtkWidget *field2, GtkWidget *error, GtkWidget *window):&#160;tools.c']]],
  ['create_5fpopup_9',['create_popup',['../tools_8c.html#a86648203b95f5de4daf60e1bc48e2e7a',1,'tools.c']]],
  ['create_5fwindow_10',['create_window',['../widgets_8c.html#aca82692e3cdaff089bbfc7f3c9f69603',1,'create_window(void):&#160;widgets.c'],['../widgets_8h.html#aca82692e3cdaff089bbfc7f3c9f69603',1,'create_window(void):&#160;widgets.c']]]
];

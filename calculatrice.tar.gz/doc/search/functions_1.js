var searchData=
[
  ['button_5fclicked_40',['button_clicked',['../tools_8c.html#a99522ac2117a052c8aba3a2093de6a3a',1,'button_clicked(GtkWidget *button, gpointer pt):&#160;tools.c'],['../tools_8h.html#a4592512f1ea945716f6878462197c38c',1,'button_clicked(GtkWidget *button, gpointer data):&#160;tools.c']]]
];

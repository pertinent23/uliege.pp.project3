var searchData=
[
  ['show_5fmessage_25',['show_message',['../tools_8c.html#a827af55c29ccfd17c251de1404ac11b2',1,'show_message(struct GtkActionData_t *data, const char *message):&#160;tools.c'],['../tools_8h.html#a827af55c29ccfd17c251de1404ac11b2',1,'show_message(struct GtkActionData_t *data, const char *message):&#160;tools.c']]]
];

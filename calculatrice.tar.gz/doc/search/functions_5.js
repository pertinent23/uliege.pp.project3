var searchData=
[
  ['is_5fvalid_5fnumber_51',['is_valid_number',['../tools_8c.html#acfeebad21b201963371597adf3314b41',1,'tools.c']]]
];

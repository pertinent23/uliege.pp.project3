var searchData=
[
  ['destroy_5fdata_11',['destroy_data',['../tools_8c.html#a81845812d8408f2864a8b2a6512f917e',1,'destroy_data(struct GtkActionData_t *data):&#160;tools.c'],['../tools_8h.html#a81845812d8408f2864a8b2a6512f917e',1,'destroy_data(struct GtkActionData_t *data):&#160;tools.c']]],
  ['destroy_5fwindow_12',['destroy_window',['../tools_8c.html#a549dcadd05e9a845993520063d86983b',1,'destroy_window(GtkWidget *window, gpointer data):&#160;tools.c'],['../tools_8h.html#a549dcadd05e9a845993520063d86983b',1,'destroy_window(GtkWidget *window, gpointer data):&#160;tools.c']]]
];

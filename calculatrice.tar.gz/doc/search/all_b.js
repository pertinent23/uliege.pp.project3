var searchData=
[
  ['widgets_2ec_28',['widgets.c',['../widgets_8c.html',1,'']]],
  ['widgets_2eh_29',['widgets.h',['../widgets_8h.html',1,'']]],
  ['window_30',['window',['../structGtkActionData__t.html#aa9263b77e104ba22a0f74338eb6be99e',1,'GtkActionData_t']]]
];

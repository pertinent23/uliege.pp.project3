var searchData=
[
  ['calc_5fheight_60',['CALC_HEIGHT',['../tools_8h.html#a4dc5112e48cbcb16bac12ff015c614ce',1,'tools.h']]],
  ['calc_5fwidth_61',['CALC_WIDTH',['../tools_8h.html#ab2b34edbd92cf0fd45937ed66979573d',1,'tools.h']]]
];

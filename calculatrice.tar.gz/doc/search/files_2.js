var searchData=
[
  ['widgets_2ec_35',['widgets.c',['../widgets_8c.html',1,'']]],
  ['widgets_2eh_36',['widgets.h',['../widgets_8h.html',1,'']]]
];

var tools_8h =
[
    [ "CALC_HEIGHT", "tools_8h.html#a4dc5112e48cbcb16bac12ff015c614ce", null ],
    [ "CALC_WIDTH", "tools_8h.html#ab2b34edbd92cf0fd45937ed66979573d", null ],
    [ "GtkActionData", "tools_8h.html#a7be5b8cbaa51c7a90c6dc90bf7278d9f", null ],
    [ "button_clicked", "tools_8h.html#a4592512f1ea945716f6878462197c38c", null ],
    [ "create_data", "tools_8h.html#acb2278452f2d44242063041e4575e8fa", null ],
    [ "destroy_data", "tools_8h.html#a81845812d8408f2864a8b2a6512f917e", null ],
    [ "destroy_window", "tools_8h.html#a549dcadd05e9a845993520063d86983b", null ],
    [ "get_field1_value", "tools_8h.html#a0b38dce5d5df7fc2ebfa1be7d9818fdc", null ],
    [ "get_field2_value", "tools_8h.html#a0d7eb53cfa942ae5fcf11b05eaedba6e", null ],
    [ "get_window", "tools_8h.html#acb804f6eda8eb14a8bad5d0bc20e7624", null ],
    [ "show_message", "tools_8h.html#a827af55c29ccfd17c251de1404ac11b2", null ]
];
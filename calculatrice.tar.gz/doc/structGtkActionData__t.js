var structGtkActionData__t =
[
    [ "error", "structGtkActionData__t.html#a844297572cbb79ad6ba49058910c6e79", null ],
    [ "field1", "structGtkActionData__t.html#ab7ad53e898feda8bab53c2088cb75881", null ],
    [ "field2", "structGtkActionData__t.html#a7e1d5d90dd6ab6e7be3e12372ea76ab5", null ],
    [ "window", "structGtkActionData__t.html#aa9263b77e104ba22a0f74338eb6be99e", null ]
];
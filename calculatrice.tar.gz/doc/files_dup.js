var files_dup =
[
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "tools.c", "tools_8c.html", "tools_8c" ],
    [ "tools.h", "tools_8h.html", "tools_8h" ],
    [ "widgets.c", "widgets_8c.html", "widgets_8c" ],
    [ "widgets.h", "widgets_8h.html", "widgets_8h" ]
];
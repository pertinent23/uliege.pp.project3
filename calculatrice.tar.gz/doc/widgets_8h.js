var widgets_8h =
[
    [ "add_button", "widgets_8h.html#abc504f2a558c0ba6d62e7a39476d7657", null ],
    [ "add_field", "widgets_8h.html#a2335f03908f020d7d0c0f725d659eefb", null ],
    [ "add_label", "widgets_8h.html#abe0f4cfa7a7afeadc5c79ab4d017fd4b", null ],
    [ "create_board", "widgets_8h.html#a61578a3ab9da9c18fe9a643b5066f669", null ],
    [ "create_button", "widgets_8h.html#a3664f09871e36b3872aa7641e880a355", null ],
    [ "create_window", "widgets_8h.html#aca82692e3cdaff089bbfc7f3c9f69603", null ]
];